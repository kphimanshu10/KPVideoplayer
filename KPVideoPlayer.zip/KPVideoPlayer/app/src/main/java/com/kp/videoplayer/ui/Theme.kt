package com.kp.videoplayer.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.data.AppSettings

val Accents = listOf(
    Color(0xFF8B7CFF), // violet (default)
    Color(0xFF1DE9B6), // mint
    Color(0xFFFF9E40), // amber
    Color(0xFF40C4FF), // sky
)

@Composable
fun KpTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val accent = Accents[settings.accent.coerceIn(0, Accents.lastIndex)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF101014),
            secondary = accent,
            background = Color(0xFF0E0F14),
            surface = Color(0xFF16181F),
            surfaceVariant = Color(0xFF22252E),
            onBackground = Color(0xFFECEDF2),
            onSurface = Color(0xFFECEDF2),
            onSurfaceVariant = Color(0xFFA7ABB8),
        )
    } else {
        lightColorScheme(
            primary = lerp(accent, Color.Black, 0.35f),
            onPrimary = Color.White,
            secondary = lerp(accent, Color.Black, 0.35f),
            background = Color(0xFFF6F6FA),
            surface = Color.White,
            surfaceVariant = Color(0xFFE9EAF1),
            onBackground = Color(0xFF14151A),
            onSurface = Color(0xFF14151A),
            onSurfaceVariant = Color(0xFF555867),
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp),
        ),
    ) {
        Surface(color = scheme.background) { content() }
    }
}
