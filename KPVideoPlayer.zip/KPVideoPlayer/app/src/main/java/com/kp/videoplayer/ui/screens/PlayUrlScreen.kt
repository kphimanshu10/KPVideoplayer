package com.kp.videoplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.ui.LibraryViewModel
import com.kp.videoplayer.util.UrlValidator

@Composable
fun PlayUrlScreen(vm: LibraryViewModel, padding: PaddingValues) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val recent by vm.urlHistory.collectAsState()
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit(raw: String) {
        when (val r = UrlValidator.validate(raw)) {
            is UrlValidator.Result.Invalid -> error = r.message
            is UrlValidator.Result.Ok -> {
                error = null
                vm.playUrl(context, r.url)
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = padding.calculateTopPadding() + 16.dp,
            bottom = padding.calculateBottomPadding() + 16.dp,
        ),
    ) {
        item {
            Text("Play from URL", style = MaterialTheme.typography.titleLarge)
            Text(
                "Paste a direct link to a video file, an HLS (.m3u8) or DASH (.mpd) stream. " +
                    "Links to web pages, DRM-protected or sign-in-only content can't be played.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
            )
            OutlinedTextField(
                value = input,
                onValueChange = { input = it; error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Media URL") },
                placeholder = { Text("https://example.com/video.mp4") },
                leadingIcon = { Icon(Icons.Filled.Link, null) },
                isError = error != null,
                supportingText = { error?.let { Text(it) } },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { submit(input) }),
            )
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { submit(input) }) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Text("Play", Modifier.padding(start = 6.dp))
                }
                OutlinedButton(
                    onClick = { clipboard.getText()?.text?.let { input = it; error = null } },
                    modifier = Modifier.padding(start = 8.dp),
                ) { Text("Paste") }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent URLs", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (recent.isNotEmpty()) TextButton(onClick = { vm.clearUrls() }) { Text("Clear") }
            }
            if (recent.isEmpty()) {
                Text(
                    "Nothing here yet. URLs you play are kept only on this device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(recent, key = { it }) { url ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { vm.playUrl(context, url) }
                    .padding(vertical = 10.dp),
            ) {
                // Show host and file name only; query strings can contain tokens.
                Text(UrlValidator.displayName(url), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
