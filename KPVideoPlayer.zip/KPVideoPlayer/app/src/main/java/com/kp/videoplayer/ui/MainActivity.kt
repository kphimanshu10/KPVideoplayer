package com.kp.videoplayer.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.kp.videoplayer.data.PlaybackQueue
import com.kp.videoplayer.data.QueueEntry
import com.kp.videoplayer.data.VideoItem
import com.kp.videoplayer.player.PlayerActivity
import com.kp.videoplayer.ui.screens.FoldersScreen
import com.kp.videoplayer.ui.screens.HistoryScreen
import com.kp.videoplayer.ui.screens.HomeScreen
import com.kp.videoplayer.ui.screens.PlayUrlScreen
import com.kp.videoplayer.ui.screens.SettingsScreen
import com.kp.videoplayer.ui.screens.VideosScreen

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Videos("Videos", Icons.Filled.Videocam),
    Folders("Folders", Icons.Filled.Folder),
    Url("URL", Icons.Filled.Link),
    History("History", Icons.Filled.History),
    Settings("Settings", Icons.Filled.Settings),
}

class MainActivity : ComponentActivity() {
    private val vm: LibraryViewModel by viewModels()
    private lateinit var deleteLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var openFileLauncher: ActivityResultLauncher<Array<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
            if (it.resultCode == RESULT_OK) {
                vm.clearSelection()
                vm.refresh()
            }
        }
        openFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { openSingle(it) }
        }

        setContent {
            val settings by vm.settings.collectAsState()
            KpTheme(settings) {
                AppRoot(
                    vm = vm,
                    onDelete = ::requestDelete,
                    onOpenFile = { openFileLauncher.launch(arrayOf("video/*", "audio/*")) },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPrefs()
    }

    private fun openSingle(uri: Uri) {
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        val name = runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.substringBeforeLast('.') else null
            }
        }.getOrNull() ?: "Video"
        PlaybackQueue.items = listOf(QueueEntry(uri.toString(), name))
        startActivity(PlayerActivity.queueIntent(this, 0))
    }

    private fun requestDelete(items: List<VideoItem>) {
        if (items.isEmpty()) return
        // Android shows its own system confirmation; nothing is deleted without the user approving it.
        val pi = MediaStore.createDeleteRequest(contentResolver, items.map { it.uri })
        deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
    }
}

private fun videoPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasVideoPermission(context: Context) =
    ContextCompat.checkSelfPermission(context, videoPermission()) == PackageManager.PERMISSION_GRANTED

@Composable
private fun AppRoot(vm: LibraryViewModel, onDelete: (List<VideoItem>) -> Unit, onOpenFile: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var granted by remember { mutableStateOf(hasVideoPermission(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok) vm.refresh()
    }
    val requestPermission = { permissionLauncher.launch(videoPermission()) }
    val openAppSettings = {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
        )
    }

    // Re-check on every resume so revoked permissions are handled.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        val now = hasVideoPermission(context)
        granted = now
        if (now) vm.refresh()
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, maxLines = 1, overflow = TextOverflow.Clip) },
                        alwaysShowLabel = true,
                    )
                }
            }
        },
    ) { padding ->
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "tabs",
        ) { current ->
            when (current) {
                Tab.Home -> HomeScreen(vm, granted, requestPermission, openAppSettings, onOpenFile, padding)
                Tab.Videos -> VideosScreen(vm, granted, requestPermission, openAppSettings, onDelete, padding)
                Tab.Folders -> FoldersScreen(vm, granted, requestPermission, openAppSettings, padding)
                Tab.Url -> PlayUrlScreen(vm, padding)
                Tab.History -> HistoryScreen(vm, padding)
                Tab.Settings -> SettingsScreen(vm, padding)
            }
        }
    }
}
