package com.kp.videoplayer.player

import android.Manifest
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import com.kp.videoplayer.KpApp
import com.kp.videoplayer.data.HistoryEntry
import com.kp.videoplayer.data.PlaybackQueue
import com.kp.videoplayer.data.PrefsStore
import com.kp.videoplayer.data.QueueEntry
import com.kp.videoplayer.playback.ErrorMessages
import com.kp.videoplayer.playback.MediaItems
import com.kp.videoplayer.playback.PlaybackService
import com.kp.videoplayer.util.UrlValidator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Full-screen player. Talks to PlaybackService through a MediaController so that playback state
 * survives the activity (background audio, notification, PiP).
 */
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_USE_QUEUE = "use_queue"
        private const val EXTRA_START = "start_index"

        fun queueIntent(ctx: Context, startIndex: Int): Intent =
            Intent(ctx, PlayerActivity::class.java)
                .putExtra(EXTRA_USE_QUEUE, true)
                .putExtra(EXTRA_START, startIndex)

        private val SPEEDS = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)
        private val RESIZE_MODES = listOf(
            "Fit" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
            "Fill" to AspectRatioFrameLayout.RESIZE_MODE_FILL,
            "Crop" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            "Width" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            "Height" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT,
        )
        private val ORIENTATIONS = listOf(
            "Auto" to ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED,
            "Landscape" to ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,
            "Portrait" to ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT,
        )
    }

    private lateinit var store: PrefsStore
    private lateinit var audioManager: AudioManager
    private lateinit var toolbar: HorizontalScrollView
    private lateinit var playerView: PlayerView
    private lateinit var indicator: TextView
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var aspectBtn: TextView
    private lateinit var rotateBtn: TextView
    private lateinit var audioOnlyBtn: TextView

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var queueLoaded = false
    private var locked = false
    private var inPip = false
    private var resizeIndex = 0
    private var orientationIndex = 0
    private var audioOnly = false
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var startBrightness = 0.5f
    private var startVolumeFraction = 0f

    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null
    private val hideIndicator = Runnable { indicator.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val saveTicker = object : Runnable {
        override fun run() {
            saveProgress()
            handler.postDelayed(this, 5_000)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* best effort */ }

    private val subtitlePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::attachSubtitle) }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = (application as KpApp).store
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        hideSystemBars()

        // Ask for the notification permission once, when playback first starts (needed for the media notification).
        if (Build.VERSION.SDK_INT >= 33 && !store.notificationAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            store.notificationAsked = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            runCatching { f.get() }
                .onSuccess { onConnected(it) }
                .onFailure { showError("Couldn't start the playback service.") }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        saveProgress()
        handler.removeCallbacks(saveTicker)
        controller?.let { c ->
            val hasVideo = c.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)
            val keepGoing = inPip || isInPictureInPictureMode ||
                (!isFinishing && (!hasVideo || store.settings.value.backgroundAudio))
            if (!keepGoing) c.pause()
            c.removeListener(listener)
        }
        playerView.player = null
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val c = controller ?: return
        if (store.settings.value.autoPip && c.isPlaying && c.videoSize.width > 0) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode && !locked
        toolbar.visibility = View.GONE
    }

    // ------------------------------------------------------------------ connection / queue

    private fun onConnected(c: MediaController) {
        controller = c
        c.addListener(listener)
        playerView.player = c
        speedBtn.text = fmtSpeed(c.playbackParameters.speed)
        if (!queueLoaded) {
            queueLoaded = true
            loadQueue(c)
        }
        handler.removeCallbacks(saveTicker)
        handler.postDelayed(saveTicker, 5_000)
    }

    private fun loadQueue(c: MediaController) {
        val entries: List<QueueEntry>
        val start: Int
        val queue = PlaybackQueue.items
        if (intent.getBooleanExtra(EXTRA_USE_QUEUE, false) && queue.isNotEmpty()) {
            entries = queue
            start = intent.getIntExtra(EXTRA_START, 0).coerceIn(0, queue.lastIndex)
        } else {
            val d = intent.data
            if (d == null) {
                // Re-opened from the notification: keep whatever the service is already playing.
                if (c.mediaItemCount == 0) showError("Nothing to play.")
                return
            }
            val scheme = d.scheme?.lowercase()
            if (scheme != "content" && scheme != "http" && scheme != "https") {
                showError("This source type isn't supported.")
                return
            }
            val title = queryName(d) ?: UrlValidator.displayName(d.toString())
            entries = listOf(QueueEntry(d.toString(), title))
            start = 0
        }
        val items = entries.map { MediaItems.build(Uri.parse(it.uri), it.title) }
        val saved = store.getResume(entries[start].uri)
        c.setMediaItems(items, start, if (saved > 5_000) saved else C.TIME_UNSET)
        c.prepare()
        c.play()
    }

    private fun queryName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.substringBeforeLast('.') else null
        }
    }.getOrNull()

    // ------------------------------------------------------------------ player events

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            showError(ErrorMessages.describe(error))
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY) errorBox.visibility = View.GONE
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem ?: return
            errorBox.visibility = View.GONE
            recordHistory(mediaItem)
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK
            ) {
                val saved = store.getResume(mediaItem.mediaId)
                if (saved > 5_000) controller?.seekTo(saved)
            }
            showIndicator(mediaItem.mediaMetadata.title?.toString().orEmpty(), 1800)
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            speedBtn.text = fmtSpeed(playbackParameters.speed)
        }

        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
            // "Auto" orientation follows the video's own shape.
            if (orientationIndex == 0 && videoSize.width > 0 && videoSize.height > 0 && !inPip) {
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
    }

    private fun recordHistory(item: MediaItem) {
        val isUrl = item.mediaId.startsWith("http", ignoreCase = true)
        val title = item.mediaMetadata.title?.toString()
            ?: if (isUrl) UrlValidator.displayName(item.mediaId) else "Video"
        store.addHistory(HistoryEntry(item.mediaId, title, isUrl, System.currentTimeMillis()))
    }

    private fun saveProgress() {
        val c = controller ?: return
        val item = c.currentMediaItem ?: return
        val pos = c.currentPosition
        val dur = c.duration
        if (dur <= 0) return
        when {
            pos >= dur - 5_000 -> store.clearResume(item.mediaId)
            pos > 5_000 -> store.setResume(item.mediaId, pos)
        }
    }

    private fun showError(message: String) {
        errorText.text = message
        errorBox.visibility = View.VISIBLE
        playerView.showController()
    }

    // ------------------------------------------------------------------ UI construction

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        minHeight = dp(40)
        setPadding(dp(14), dp(6), dp(14), dp(6))
        background = GradientDrawable().apply {
            setColor(0x99000000.toInt())
            cornerRadius = dp(20).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { marginEnd = dp(8) }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Top toolbar (follows controller visibility).
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        speedBtn = chip("1x") { showSpeedDialog() }
        aspectBtn = chip(RESIZE_MODES[0].first) { cycleAspect() }
        rotateBtn = chip(ORIENTATIONS[0].first) { cycleOrientation() }
        audioOnlyBtn = chip("Audio only") { toggleAudioOnly() }
        row.addView(speedBtn)
        row.addView(aspectBtn)
        row.addView(chip("Audio") { showTrackDialog(C.TRACK_TYPE_AUDIO, "Audio track") })
        row.addView(chip("Subtitles") { showTrackDialog(C.TRACK_TYPE_TEXT, "Subtitles") })
        row.addView(chip("Add subtitle file") { subtitlePicker.launch(arrayOf("*/*")) })
        row.addView(rotateBtn)
        row.addView(audioOnlyBtn)
        row.addView(chip("Sleep timer") { showSleepDialog() })
        row.addView(chip("PiP") { enterPip() })
        row.addView(chip("Lock") { lock() })
        row.addView(chip("Info") { showInfoDialog() })
        toolbar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
            addView(row)
        }

        playerView = PlayerView(this).apply {
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            controllerShowTimeoutMs = 3_000
            setControllerVisibilityListener(
                PlayerView.ControllerVisibilityListener { v ->
                    toolbar.visibility = if (locked || inPip) View.GONE else v
                },
            )
            setOnTouchListener { _, ev -> handleTouch(ev) }
        }

        indicator = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                setColor(0xB0000000.toInt())
                cornerRadius = dp(14).toFloat()
            }
            visibility = View.GONE
        }

        errorText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val retry = Button(this).apply {
            text = "Retry"
            setOnClickListener {
                controller?.let { it.prepare(); it.play() }
                errorBox.visibility = View.GONE
            }
        }
        errorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(24), dp(32), dp(24))
            background = GradientDrawable().apply {
                setColor(0xE6101014.toInt())
                cornerRadius = dp(16).toFloat()
            }
            visibility = View.GONE
            addView(errorText)
            addView(retry)
        }

        unlockBtn = chip("Unlock") { unlock() }.apply { visibility = View.GONE }

        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        root.addView(toolbar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        root.addView(indicator, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(
            errorBox,
            FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { marginStart = dp(24); marginEnd = dp(24) },
        )
        root.addView(
            unlockBtn,
            FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.END).apply { marginEnd = dp(24) },
        )
        setContentView(root)
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ------------------------------------------------------------------ gestures

    private val gestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    showUnlockButton()
                } else if (playerView.isControllerFullyVisible) {
                    playerView.hideController()
                } else {
                    playerView.showController()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = playerView.width.toFloat()
                val step = store.settings.value.seekStepSec * 1000L
                when {
                    e.x < w / 3f -> seekBy(-step)
                    e.x > w * 2f / 3f -> seekBy(step)
                    else -> controller?.let { if (it.isPlaying) it.pause() else it.play() }
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null) return false
                if (gestureMode == 0) {
                    if (abs(dy) < abs(dx)) return false
                    gestureMode = if (e1.x < playerView.width / 2f) 1 else 2
                    startBrightness = currentBrightness()
                    val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    startVolumeFraction = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
                }
                val delta = (e1.y - e2.y) / playerView.height.coerceAtLeast(1)
                if (gestureMode == 1) {
                    val b = (startBrightness + delta).coerceIn(0.01f, 1f)
                    window.attributes = window.attributes.apply { screenBrightness = b }
                    showIndicator("Brightness ${(b * 100).roundToInt()}%", 700)
                } else {
                    val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    val f = (startVolumeFraction + delta).coerceIn(0f, 1f)
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt(), 0)
                    showIndicator("Volume ${(f * 100).roundToInt()}%", 700)
                }
                return true
            }
        })
    }

    private fun handleTouch(ev: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            gestureMode = 0
        }
        return true
    }

    private fun currentBrightness(): Float {
        val w = window.attributes.screenBrightness
        if (w >= 0f) return w
        return runCatching {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        }.getOrDefault(0.5f)
    }

    private fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        val dur = c.duration
        var target = c.currentPosition + deltaMs
        target = if (dur > 0) target.coerceIn(0, dur) else target.coerceAtLeast(0)
        c.seekTo(target)
        showIndicator(if (deltaMs > 0) "+${deltaMs / 1000}s" else "${deltaMs / 1000}s", 600)
    }

    private fun showIndicator(text: String, ms: Long) {
        if (text.isBlank()) return
        indicator.text = text
        indicator.visibility = View.VISIBLE
        handler.removeCallbacks(hideIndicator)
        handler.postDelayed(hideIndicator, ms)
    }

    // ------------------------------------------------------------------ toolbar actions

    private fun fmtSpeed(s: Float) =
        (if (s == s.toInt().toFloat()) s.toInt().toString() else String.format(Locale.US, "%.2f", s).trimEnd('0')) + "x"

    private fun showSpeedDialog() {
        val c = controller ?: return
        val labels = SPEEDS.map { fmtSpeed(it) }.toTypedArray()
        val checked = SPEEDS.indexOfFirst { abs(it - c.playbackParameters.speed) < 0.01f }
        AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setSingleChoiceItems(labels, checked) { d, which ->
                c.setPlaybackSpeed(SPEEDS[which])
                d.dismiss()
            }
            .show()
    }

    private fun cycleAspect() {
        resizeIndex = (resizeIndex + 1) % RESIZE_MODES.size
        playerView.resizeMode = RESIZE_MODES[resizeIndex].second
        aspectBtn.text = RESIZE_MODES[resizeIndex].first
        showIndicator("Aspect: ${RESIZE_MODES[resizeIndex].first}", 800)
    }

    private fun cycleOrientation() {
        orientationIndex = (orientationIndex + 1) % ORIENTATIONS.size
        requestedOrientation = ORIENTATIONS[orientationIndex].second
        rotateBtn.text = ORIENTATIONS[orientationIndex].first
    }

    private fun toggleAudioOnly() {
        val c = controller ?: return
        audioOnly = !audioOnly
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
            .build()
        audioOnlyBtn.text = if (audioOnly) "Video on" else "Audio only"
    }

    private data class TrackOption(val label: String, val group: Tracks.Group?, val index: Int, val selected: Boolean)

    private fun showTrackDialog(type: Int, title: String) {
        val c = controller ?: return
        val options = mutableListOf<TrackOption>()
        val textDisabled = c.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        if (type == C.TRACK_TYPE_TEXT) options += TrackOption("Off", null, -1, textDisabled)
        var n = 1
        for (g in c.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val parts = listOfNotNull(
                    f.label,
                    f.language?.takeIf { it != "und" }?.let { Locale.forLanguageTag(it).displayLanguage },
                    if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) "${f.channelCount}ch" else null,
                )
                val label = parts.distinct().joinToString(" · ").ifBlank { "Track $n" }
                val sel = g.isTrackSelected(i) && !(type == C.TRACK_TYPE_TEXT && textDisabled)
                options += TrackOption(label, g, i, sel)
                n++
            }
        }
        if (options.none { it.group != null }) {
            Toast.makeText(
                this,
                if (type == C.TRACK_TYPE_TEXT) "No subtitle tracks in this video." else "No selectable audio tracks.",
                Toast.LENGTH_SHORT,
            ).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(
                options.map { it.label }.toTypedArray(),
                options.indexOfFirst { it.selected },
            ) { d, which ->
                val o = options[which]
                val b = c.trackSelectionParameters.buildUpon()
                if (o.group == null) {
                    b.setTrackTypeDisabled(type, true)
                } else {
                    b.setTrackTypeDisabled(type, false)
                    b.setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index))
                }
                c.trackSelectionParameters = b.build()
                d.dismiss()
            }
            .show()
    }

    private fun attachSubtitle(uri: Uri) {
        val c = controller ?: return
        val current = c.currentMediaItem ?: return
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val name = runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(MediaItems.subtitleMime(name))
            .setLanguage("und")
            .setLabel(name.ifBlank { "External subtitle" })
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val index = c.currentMediaItemIndex
        val pos = c.currentPosition
        val wasPlaying = c.playWhenReady
        val items = (0 until c.mediaItemCount).map { i ->
            if (i == index) current.buildUpon().setSubtitleConfigurations(listOf(sub)).build() else c.getMediaItemAt(i)
        }
        c.setMediaItems(items, index, pos)
        c.prepare()
        c.playWhenReady = wasPlaying
        // Make sure subtitles are enabled after attaching.
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        Toast.makeText(this, "Subtitle file added", Toast.LENGTH_SHORT).show()
    }

    private fun showSleepDialog() {
        val minutes = intArrayOf(0, 15, 30, 45, 60, 90)
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, which ->
                sleepRunnable?.let { handler.removeCallbacks(it) }
                sleepRunnable = null
                if (minutes[which] > 0) {
                    val r = Runnable {
                        controller?.pause()
                        Toast.makeText(this, "Sleep timer: playback paused", Toast.LENGTH_LONG).show()
                    }
                    sleepRunnable = r
                    handler.postDelayed(r, minutes[which] * 60_000L)
                    Toast.makeText(this, "Pausing in ${labels[which]}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Sleep timer off", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showInfoDialog() {
        val c = controller ?: return
        val lines = mutableListOf<String>()
        lines += "Title: ${c.currentMediaItem?.mediaMetadata?.title ?: "-"}"
        val vs = c.videoSize
        if (vs.width > 0) lines += "Resolution: ${vs.width}×${vs.height}"
        for (g in c.currentTracks.groups) {
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                val f = g.getTrackFormat(i)
                val kind = when (g.type) {
                    C.TRACK_TYPE_VIDEO -> "Video"
                    C.TRACK_TYPE_AUDIO -> "Audio"
                    C.TRACK_TYPE_TEXT -> "Subtitles"
                    else -> continue
                }
                val bits = listOfNotNull(
                    f.sampleMimeType,
                    f.codecs,
                    if (f.bitrate > 0) "${f.bitrate / 1000} kbps" else null,
                    if (f.frameRate > 0) "${f.frameRate.roundToInt()} fps" else null,
                )
                lines += "$kind: ${bits.joinToString(" · ")}"
            }
        }
        AlertDialog.Builder(this).setTitle("Media info").setMessage(lines.joinToString("\n")).setPositiveButton("OK", null).show()
    }

    private fun lock() {
        locked = true
        playerView.useController = false
        toolbar.visibility = View.GONE
        showUnlockButton()
    }

    private fun unlock() {
        locked = false
        unlockBtn.visibility = View.GONE
        playerView.useController = !inPip
        playerView.showController()
    }

    private fun showUnlockButton() {
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2_500)
    }

    private fun enterPip() {
        val vs = controller?.videoSize
        val w = vs?.width ?: 0
        val h = vs?.height ?: 0
        val ratio = if (w > 0 && h > 0) {
            val r = w.toFloat() / h
            when {
                r > 2.39f -> Rational(239, 100)
                r < 0.4184f -> Rational(100, 239)
                else -> Rational(w, h)
            }
        } else Rational(16, 9)
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (_: IllegalStateException) {
            Toast.makeText(this, "Picture-in-Picture isn't available here.", Toast.LENGTH_SHORT).show()
        }
    }
}
