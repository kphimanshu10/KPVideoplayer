package com.kp.videoplayer.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.data.SortOrder
import com.kp.videoplayer.data.VideoItem
import com.kp.videoplayer.ui.EmptyState
import com.kp.videoplayer.ui.LibraryViewModel
import com.kp.videoplayer.ui.PermissionPrompt
import com.kp.videoplayer.ui.VideoCollection

@Composable
fun VideosScreen(
    vm: LibraryViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onDelete: (List<VideoItem>) -> Unit,
    padding: PaddingValues,
) {
    val context = LocalContext.current
    val videos by vm.visibleVideos.collectAsState()
    val all by vm.allVideos.collectAsState()
    val loading by vm.loading.collectAsState()
    val query by vm.query.collectAsState()
    val sort by vm.sort.collectAsState()
    val grid by vm.grid.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val selection by vm.selection.collectAsState()
    var sortMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val selected = videos.filter { it.id in selection }

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())) {
        if (selection.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.clearSelection() }) { Icon(Icons.Filled.Close, "Clear selection") }
                Text("${selection.size} selected", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { vm.playQueue(context, selected, 0); vm.clearSelection() }) {
                    Icon(Icons.Filled.PlayArrow, "Play selected as queue")
                }
                IconButton(onClick = { selected.forEach { vm.toggleFavorite(it.key) }; vm.clearSelection() }) {
                    Icon(Icons.Filled.Favorite, "Toggle favorites")
                }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete selected") }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { vm.query.value = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Search videos") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Filled.Close, "Clear search") }
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.large,
                    keyboardOptions = KeyboardOptions.Default,
                )
                Box {
                    IconButton(onClick = { sortMenu = true }) { Icon(Icons.Filled.Sort, "Sort") }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        SortOrder.values().forEach { o ->
                            DropdownMenuItem(
                                text = { Text(o.label, color = if (o == sort) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) },
                                onClick = { vm.sort.value = o; sortMenu = false },
                            )
                        }
                    }
                }
                IconButton(onClick = { vm.grid.value = !grid }) {
                    Icon(if (grid) Icons.Filled.Menu else Icons.Filled.GridView, if (grid) "List view" else "Grid view")
                }
                IconButton(onClick = { vm.refresh() }) { Icon(Icons.Filled.Refresh, "Refresh") }
            }
        }

        when {
            !granted -> PermissionPrompt(onRequestPermission, onOpenAppSettings)
            loading && all.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            videos.isEmpty() -> EmptyState(
                Icons.Filled.Videocam,
                if (query.isBlank()) "No videos found" else "No matches",
                if (query.isBlank()) "Videos stored on this device will appear here." else "Try a different search.",
            )
            else -> VideoCollection(
                videos = videos, grid = grid, favorites = favorites, selection = selection,
                progressOf = { vm.resumeFraction(it.key, it.durationMs) },
                onClick = { i ->
                    if (selection.isNotEmpty()) vm.toggleSelect(videos[i].id) else vm.playQueue(context, videos, i)
                },
                onLongClick = { vm.toggleSelect(it.id) },
                onFavorite = { vm.toggleFavorite(it.key) },
                modifier = Modifier.fillMaxSize(),
            )
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${selected.size} video(s)?") },
            text = { Text("Android will ask you to confirm. Deleted files can't be recovered by this app.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete(selected) }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}
