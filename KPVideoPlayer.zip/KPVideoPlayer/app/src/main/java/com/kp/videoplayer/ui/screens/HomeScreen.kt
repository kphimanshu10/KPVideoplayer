package com.kp.videoplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.data.VideoItem
import com.kp.videoplayer.ui.DurationBadge
import com.kp.videoplayer.ui.LibraryViewModel
import com.kp.videoplayer.ui.PermissionPrompt
import com.kp.videoplayer.ui.SectionHeader
import com.kp.videoplayer.ui.ThumbBox
import com.kp.videoplayer.util.Fmt

@Composable
fun HomeScreen(
    vm: LibraryViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenFile: () -> Unit,
    padding: PaddingValues,
) {
    val context = LocalContext.current
    val videos by vm.allVideos.collectAsState()
    val history by vm.history.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val byKey = videos.associateBy { it.key }
    val recent = videos.sortedByDescending { it.dateAddedSec }.take(12)
    val favVideos = videos.filter { it.key in favorites }.take(12)
    val continueWatching = history.filter { vm.resumeFraction(it.key, byKey[it.key]?.durationMs ?: 0L) != null }.take(12)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(
        top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding() + 16.dp,
    )) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary)
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("KP Video Player", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Your videos, your way",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                FilledTonalButton(onClick = onOpenFile) {
                    Icon(Icons.Filled.FolderOpen, null, Modifier.size(18.dp))
                    Text("Open file", Modifier.padding(start = 6.dp))
                }
            }
        }

        if (!granted) {
            item {
                Box(Modifier.fillMaxWidth().height(320.dp)) {
                    PermissionPrompt(onRequestPermission, onOpenAppSettings)
                }
            }
        }

        if (continueWatching.isNotEmpty()) {
            item { SectionHeader("Continue watching") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(continueWatching, key = { it.key }) { h ->
                        val v = byKey[h.key]
                        Tile(
                            title = h.title,
                            subtitle = if (h.isUrl) "Network stream" else v?.let { Fmt.duration(it.durationMs) } ?: "",
                            video = v,
                            isUrl = h.isUrl,
                            progress = vm.resumeFraction(h.key, v?.durationMs ?: 0L),
                            onClick = { vm.playKey(context, h.key, h.title) },
                        )
                    }
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { SectionHeader("Recently added") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recent, key = { it.id }) { v ->
                        Tile(
                            title = v.title, subtitle = Fmt.duration(v.durationMs), video = v, isUrl = false,
                            progress = vm.resumeFraction(v.key, v.durationMs),
                            onClick = { vm.playQueue(context, recent, recent.indexOf(v)) },
                        )
                    }
                }
            }
        }

        if (favVideos.isNotEmpty()) {
            item { SectionHeader("Favorites") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(favVideos, key = { it.id }) { v ->
                        Tile(
                            title = v.title, subtitle = Fmt.duration(v.durationMs), video = v, isUrl = false,
                            progress = vm.resumeFraction(v.key, v.durationMs),
                            onClick = { vm.playQueue(context, favVideos, favVideos.indexOf(v)) },
                        )
                    }
                }
            }
        }

        if (granted && videos.isEmpty() && history.isEmpty()) {
            item {
                Text(
                    "No videos found yet. Open a file, play a URL, or add videos to your device.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Tile(
    title: String,
    subtitle: String,
    video: VideoItem?,
    isUrl: Boolean,
    progress: Float?,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .width(200.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            ThumbBox(video, isUrl, Modifier.fillMaxSize())
            if (video != null) DurationBadge(Fmt.duration(video.durationMs), Modifier.align(Alignment.BottomEnd))
            if (progress != null) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                )
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge)
            if (subtitle.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
