package com.kp.videoplayer.data

import android.net.Uri

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val folder: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val width: Int,
    val height: Int,
    val mime: String,
) {
    val key: String get() = uri.toString()
}

data class HistoryEntry(
    val key: String,
    val title: String,
    val isUrl: Boolean,
    val playedAt: Long,
)

data class QueueEntry(val uri: String, val title: String)

/** In-process hand-off of the playback queue to PlayerActivity (avoids Binder size limits). */
object PlaybackQueue {
    @Volatile
    var items: List<QueueEntry> = emptyList()
}

data class AppSettings(
    val themeMode: Int = 1, // 0 system, 1 dark, 2 light
    val accent: Int = 0,
    val backgroundAudio: Boolean = false,
    val autoPip: Boolean = true,
    val seekStepSec: Int = 10,
    val bufferLevel: Int = 1, // 0 low, 1 normal, 2 high
)

enum class SortOrder(val label: String) {
    DATE_DESC("Newest first"),
    DATE_ASC("Oldest first"),
    NAME_ASC("Name A–Z"),
    NAME_DESC("Name Z–A"),
    DURATION_DESC("Longest first"),
    DURATION_ASC("Shortest first"),
    SIZE_DESC("Largest first"),
    SIZE_ASC("Smallest first"),
}

fun sortVideos(list: List<VideoItem>, order: SortOrder): List<VideoItem> = when (order) {
    SortOrder.DATE_DESC -> list.sortedByDescending { it.dateAddedSec }
    SortOrder.DATE_ASC -> list.sortedBy { it.dateAddedSec }
    SortOrder.NAME_ASC -> list.sortedBy { it.title.lowercase() }
    SortOrder.NAME_DESC -> list.sortedByDescending { it.title.lowercase() }
    SortOrder.DURATION_DESC -> list.sortedByDescending { it.durationMs }
    SortOrder.DURATION_ASC -> list.sortedBy { it.durationMs }
    SortOrder.SIZE_DESC -> list.sortedByDescending { it.sizeBytes }
    SortOrder.SIZE_ASC -> list.sortedBy { it.sizeBytes }
}
