package com.kp.videoplayer.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kp.videoplayer.KpApp
import com.kp.videoplayer.data.AppSettings
import com.kp.videoplayer.data.PlaybackQueue
import com.kp.videoplayer.data.QueueEntry
import com.kp.videoplayer.data.SortOrder
import com.kp.videoplayer.data.VideoItem
import com.kp.videoplayer.data.sortVideos
import com.kp.videoplayer.player.PlayerActivity
import com.kp.videoplayer.util.UrlValidator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val store = (app as KpApp).store
    private val repo = (app as KpApp).repo

    val settings: StateFlow<AppSettings> = store.settings
    val allVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    val loading = MutableStateFlow(false)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.DATE_DESC)
    val grid = MutableStateFlow(false)
    val favorites = MutableStateFlow(store.favorites())
    val history = MutableStateFlow(store.history())
    val urlHistory = MutableStateFlow(store.urlHistory())
    val selection = MutableStateFlow<Set<Long>>(emptySet())

    val visibleVideos: StateFlow<List<VideoItem>> =
        combine(allVideos, query, sort) { videos, q, s ->
            val filtered = if (q.isBlank()) videos else videos.filter {
                it.title.contains(q, ignoreCase = true) || it.folder.contains(q, ignoreCase = true)
            }
            sortVideos(filtered, s)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun refresh() {
        viewModelScope.launch {
            loading.value = true
            allVideos.value = repo.loadAll()
            loading.value = false
        }
    }

    /** Re-read prefs after returning from the player (history / resume changed there). */
    fun refreshPrefs() {
        history.value = store.history()
        urlHistory.value = store.urlHistory()
        favorites.value = store.favorites()
    }

    fun toggleFavorite(key: String) {
        favorites.value = store.toggleFavorite(key)
    }

    fun toggleSelect(id: Long) {
        selection.value = selection.value.let { if (id in it) it - id else it + id }
    }

    fun clearSelection() {
        selection.value = emptySet()
    }

    fun resumeFraction(key: String, durationMs: Long): Float? {
        val p = store.getResume(key)
        return if (p > 0 && durationMs > 0) (p.toFloat() / durationMs).coerceIn(0f, 1f) else null
    }

    fun updateSettings(block: (AppSettings) -> AppSettings) = store.updateSettings(block)

    fun clearHistory() {
        store.clearHistory()
        refreshPrefs()
    }

    fun addUrl(url: String) {
        store.addUrl(url)
        refreshPrefs()
    }

    fun clearUrls() {
        store.clearUrls()
        refreshPrefs()
    }

    // ---- launching the player ----
    fun playQueue(context: Context, videos: List<VideoItem>, index: Int) {
        PlaybackQueue.items = videos.map { QueueEntry(it.uri.toString(), it.title) }
        context.startActivity(PlayerActivity.queueIntent(context, index))
    }

    fun playKey(context: Context, key: String, title: String) {
        PlaybackQueue.items = listOf(QueueEntry(key, title))
        context.startActivity(PlayerActivity.queueIntent(context, 0))
    }

    fun playUrl(context: Context, url: String) {
        addUrl(url)
        playKey(context, url, UrlValidator.displayName(url))
    }
}
