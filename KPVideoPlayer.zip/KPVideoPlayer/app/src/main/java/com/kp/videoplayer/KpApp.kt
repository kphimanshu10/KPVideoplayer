package com.kp.videoplayer

import android.app.Application
import com.kp.videoplayer.data.PrefsStore
import com.kp.videoplayer.data.VideoRepository

class KpApp : Application() {
    lateinit var store: PrefsStore
        private set
    lateinit var repo: VideoRepository
        private set

    override fun onCreate() {
        super.onCreate()
        store = PrefsStore(this)
        repo = VideoRepository(this)
    }
}
