package com.kp.videoplayer.util

import java.net.URI
import java.net.URISyntaxException

/** Pure-Kotlin URL checks (JVM-testable). Never logs URLs. */
object UrlValidator {

    sealed interface Result {
        data class Ok(val url: String) : Result
        data class Invalid(val message: String) : Result
    }

    private val pageHosts = setOf(
        "youtube.com", "youtu.be", "vimeo.com", "facebook.com", "instagram.com",
        "netflix.com", "tiktok.com", "twitter.com", "x.com", "primevideo.com", "hotstar.com",
    )
    private val pageExtensions = setOf("html", "htm", "php", "asp", "aspx", "jsp")

    fun validate(raw: String): Result {
        val s = raw.trim()
        if (s.isEmpty()) return Result.Invalid("Enter a media URL.")
        if (s.any { it.isWhitespace() }) return Result.Invalid("The URL must not contain spaces.")
        val uri = try {
            URI(s)
        } catch (_: URISyntaxException) {
            return Result.Invalid("That doesn't look like a valid URL.")
        }
        val scheme = uri.scheme?.lowercase()
            ?: return Result.Invalid("Start the URL with http:// or https://.")
        if (scheme != "http" && scheme != "https") {
            return Result.Invalid("Only http:// and https:// URLs are supported.")
        }
        val host = uri.host?.lowercase() ?: return Result.Invalid("The URL has no host name.")
        val bare = host.removePrefix("www.")
        if (pageHosts.any { bare == it || bare.endsWith(".$it") }) {
            return Result.Invalid(
                "This is a website page, not a direct media file. Those sites need their own " +
                    "player (and often DRM or sign-in) and can't be played here.",
            )
        }
        val ext = uri.path?.substringAfterLast('.', "")?.lowercase().orEmpty()
        if (ext in pageExtensions) {
            return Result.Invalid(
                "This looks like a web page rather than a media file. Use a direct link to a " +
                    "video, .m3u8 (HLS) or .mpd (DASH) stream.",
            )
        }
        return Result.Ok(s)
    }

    /** Short label without query string or credentials, safe to show in lists. */
    fun displayName(url: String): String = runCatching {
        val u = URI(url)
        val last = u.path?.trimEnd('/')?.substringAfterLast('/').orEmpty()
        listOfNotNull(u.host, last.ifBlank { null }).joinToString(" / ")
    }.getOrNull()?.ifBlank { null } ?: "Network stream"
}
