package com.kp.videoplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.ui.EmptyState
import com.kp.videoplayer.ui.LibraryViewModel
import com.kp.videoplayer.ui.ThumbBox
import com.kp.videoplayer.util.UrlValidator
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(vm: LibraryViewModel, padding: PaddingValues) {
    val context = LocalContext.current
    val history by vm.history.collectAsState()
    val videos by vm.allVideos.collectAsState()
    val byKey = videos.associateBy { it.key }
    val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Watch history", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            if (history.isNotEmpty()) TextButton(onClick = { vm.clearHistory() }) { Text("Clear all") }
        }
        if (history.isEmpty()) {
            EmptyState(Icons.Filled.History, "Nothing watched yet", "Videos and streams you play will be listed here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(8.dp)) {
                items(history, key = { it.key }) { h ->
                    val v = byKey[h.key]
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { vm.playKey(context, h.key, h.title) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ThumbBox(v, h.isUrl, Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(
                                if (h.isUrl) UrlValidator.displayName(h.key) else h.title,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                fmt.format(Date(h.playedAt)),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
