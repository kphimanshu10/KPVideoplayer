package com.kp.videoplayer.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.ui.Accents
import com.kp.videoplayer.ui.LibraryViewModel

private const val PRIVACY_TEXT =
    "KP Video Player keeps everything on your device.\n\n" +
        "• Your videos are read only through Android's media library, or files you open yourself.\n" +
        "• Watch history, resume positions, favorites and recent URLs are stored in app-private storage and are never uploaded.\n" +
        "• Network streams connect directly from your device to the server you enter; the app has no analytics, ads or trackers.\n" +
        "• You can clear history and URLs at any time in Settings.\n" +
        "• Notification permission is used only for the playback notification."

@Composable
fun SettingsScreen(vm: LibraryViewModel, padding: PaddingValues) {
    val s by vm.settings.collectAsState()
    var showPrivacy by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding() + 16.dp),
    ) {
        Header("Appearance")
        ChoiceRow("Theme", listOf("System", "Dark", "Light"), s.themeMode) { i -> vm.updateSettings { it.copy(themeMode = i) } }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Accent", Modifier.padding(end = 8.dp))
            Accents.forEachIndexed { i, c ->
                Row(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(c)
                        .border(if (i == s.accent) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(0.dp, c), CircleShape)
                        .clickable { vm.updateSettings { it.copy(accent = i) } },
                ) {}
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Header("Playback")
        SwitchRow("Keep playing in background", "Continue audio when you leave a video (shows a media notification).", s.backgroundAudio) { v ->
            vm.updateSettings { it.copy(backgroundAudio = v) }
        }
        SwitchRow("Auto Picture-in-Picture", "Shrink the video into a floating window when you leave the player.", s.autoPip) { v ->
            vm.updateSettings { it.copy(autoPip = v) }
        }
        val steps = listOf(5, 10, 30)
        ChoiceRow("Double-tap seek", steps.map { "${it}s" }, steps.indexOf(s.seekStepSec).coerceAtLeast(0)) { i ->
            vm.updateSettings { it.copy(seekStepSec = steps[i]) }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Header("Network streams")
        ChoiceRow("Buffering", listOf("Low", "Normal", "High"), s.bufferLevel) { i -> vm.updateSettings { it.copy(bufferLevel = i) } }
        Text(
            "Takes effect the next time the playback service starts (close the player and the app, then reopen).",
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Header("Privacy")
        TextButton(onClick = { vm.clearHistory() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Clear watch history and resume positions") }
        TextButton(onClick = { vm.clearUrls() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Clear recent URLs") }
        TextButton(onClick = { showPrivacy = true }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Privacy policy") }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Header("About")
        Text(
            "KP Video Player 1.0.0\nPlayback powered by AndroidX Media3 (Apache License 2.0). See LICENSES-THIRD-PARTY.md.",
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text("Privacy policy") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(PRIVACY_TEXT) } },
            confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun Header(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
    )
}

@Composable
private fun ChoiceRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, o ->
                FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) })
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
