package com.kp.videoplayer.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kp.videoplayer.data.sortVideos
import com.kp.videoplayer.ui.EmptyState
import com.kp.videoplayer.ui.LibraryViewModel
import com.kp.videoplayer.ui.PermissionPrompt
import com.kp.videoplayer.ui.VideoCollection

@Composable
fun FoldersScreen(
    vm: LibraryViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onOpenAppSettings: () -> Unit,
    padding: PaddingValues,
) {
    val context = LocalContext.current
    val all by vm.allVideos.collectAsState()
    val sort by vm.sort.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val selection by vm.selection.collectAsState()
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = open != null) { open = null }

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())) {
        when {
            !granted -> PermissionPrompt(onRequestPermission, onOpenAppSettings)
            all.isEmpty() -> EmptyState(Icons.Filled.Folder, "No folders yet", "Folders containing videos will appear here.")
            open == null -> {
                val folders = all.groupBy { it.folder }.toSortedMap(compareBy<String> { it.lowercase() })
                LazyColumn(contentPadding = PaddingValues(12.dp)) {
                    items(folders.entries.toList(), key = { it.key }) { (name, list) ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable { open = name }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                            Column(Modifier.padding(start = 14.dp)) {
                                Text(name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${list.size} video${if (list.size == 1) "" else "s"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
            else -> {
                val videos = sortVideos(all.filter { it.folder == open }, sort)
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { open = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back to folders") }
                    Text(open ?: "", style = MaterialTheme.typography.titleMedium)
                }
                VideoCollection(
                    videos = videos, grid = false, favorites = favorites, selection = selection,
                    progressOf = { vm.resumeFraction(it.key, it.durationMs) },
                    onClick = { i -> vm.playQueue(context, videos, i) },
                    onLongClick = { vm.toggleFavorite(it.key) },
                    onFavorite = { vm.toggleFavorite(it.key) },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}
