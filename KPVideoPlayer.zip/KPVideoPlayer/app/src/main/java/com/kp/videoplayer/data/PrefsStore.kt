package com.kp.videoplayer.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * All persisted state lives in app-private SharedPreferences. Nothing here is uploaded anywhere.
 */
class PrefsStore(context: Context) {
    private val p = context.getSharedPreferences("kp_prefs", Context.MODE_PRIVATE)
    private val resume = context.getSharedPreferences("kp_resume", Context.MODE_PRIVATE)

    val settings = MutableStateFlow(readSettings())

    private fun readSettings() = AppSettings(
        themeMode = p.getInt("theme", 1),
        accent = p.getInt("accent", 0),
        backgroundAudio = p.getBoolean("bg_audio", false),
        autoPip = p.getBoolean("auto_pip", true),
        seekStepSec = p.getInt("seek_step", 10),
        bufferLevel = p.getInt("buffer", 1),
    )

    fun updateSettings(block: (AppSettings) -> AppSettings) {
        val n = block(settings.value)
        settings.value = n
        p.edit()
            .putInt("theme", n.themeMode)
            .putInt("accent", n.accent)
            .putBoolean("bg_audio", n.backgroundAudio)
            .putBoolean("auto_pip", n.autoPip)
            .putInt("seek_step", n.seekStepSec)
            .putInt("buffer", n.bufferLevel)
            .apply()
    }

    var notificationAsked: Boolean
        get() = p.getBoolean("notif_asked", false)
        set(v) = p.edit().putBoolean("notif_asked", v).apply()

    // ---- favorites ----
    fun favorites(): Set<String> = HashSet(p.getStringSet("fav", emptySet()) ?: emptySet())

    fun toggleFavorite(key: String): Set<String> {
        val s = favorites().toMutableSet()
        if (!s.add(key)) s.remove(key)
        p.edit().putStringSet("fav", s).apply()
        return s
    }

    // ---- watch history ----
    fun history(): List<HistoryEntry> = runCatching {
        val arr = JSONArray(p.getString("history", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(o.getString("k"), o.getString("t"), o.optBoolean("u"), o.optLong("ts"))
        }
    }.getOrDefault(emptyList())

    fun addHistory(e: HistoryEntry) {
        val list = (listOf(e) + history().filterNot { it.key == e.key }).take(200)
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("k", it.key).put("t", it.title).put("u", it.isUrl).put("ts", it.playedAt))
        }
        p.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        p.edit().remove("history").apply()
        resume.edit().clear().apply()
    }

    // ---- resume positions ----
    fun getResume(key: String): Long = resume.getLong(key, 0L)
    fun setResume(key: String, posMs: Long) = resume.edit().putLong(key, posMs).apply()
    fun clearResume(key: String) = resume.edit().remove(key).apply()

    // ---- recent URLs ----
    fun urlHistory(): List<String> = runCatching {
        val arr = JSONArray(p.getString("urls", "[]"))
        (0 until arr.length()).map { arr.getString(it) }
    }.getOrDefault(emptyList())

    fun addUrl(url: String) {
        val list = (listOf(url) + urlHistory().filterNot { it == url }).take(20)
        p.edit().putString("urls", JSONArray(list).toString()).apply()
    }

    fun clearUrls() = p.edit().remove("urls").apply()
}
