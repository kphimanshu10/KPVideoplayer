package com.kp.videoplayer.playback

import androidx.media3.common.PlaybackException

/** Turns Media3 error codes into messages that say what is actually wrong. */
object ErrorMessages {
    fun describe(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED ->
            "This device can't decode this video or audio format (codec or resolution not supported by its decoders)."

        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
            "This isn't a playable media file, or its container format isn't supported. If it came from a URL, the link may point to a web page."

        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ->
            "The file looks corrupted or incomplete."

        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Couldn't reach the server. Check your connection and try again."

        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
            "The server refused the request. The link may have expired or may require sign-in."

        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
            "The file no longer exists (it may have been moved or deleted)."

        PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
            "Access to this file was denied. Re-grant storage permission or re-open the file."

        PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW ->
            "Playback fell behind the live stream. Try again."

        else -> "Playback failed (${e.errorCodeName})."
    }
}
