package com.kp.videoplayer

import com.kp.videoplayer.util.Fmt
import org.junit.Assert.assertEquals
import org.junit.Test

class FmtAndSortTest {
    @Test fun durationFormatting() {
        assertEquals("0:00", Fmt.duration(0))
        assertEquals("0:09", Fmt.duration(9_000))
        assertEquals("1:05", Fmt.duration(65_000))
        assertEquals("1:01:01", Fmt.duration(3_661_000))
    }

    @Test fun sizeFormatting() {
        assertEquals("0 B", Fmt.size(0))
        assertEquals("512 B", Fmt.size(512))
        assertEquals("1.0 KB", Fmt.size(1024))
        assertEquals("1.5 MB", Fmt.size(1_572_864))
    }
}
