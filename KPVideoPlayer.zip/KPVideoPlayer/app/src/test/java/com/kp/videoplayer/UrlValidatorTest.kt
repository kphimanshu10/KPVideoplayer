package com.kp.videoplayer

import com.kp.videoplayer.util.UrlValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlValidatorTest {

    private fun ok(url: String) = assertTrue("expected OK for $url", UrlValidator.validate(url) is UrlValidator.Result.Ok)
    private fun bad(url: String) = assertTrue("expected Invalid for $url", UrlValidator.validate(url) is UrlValidator.Result.Invalid)

    @Test fun acceptsDirectMediaLinks() {
        ok("https://example.com/video.mp4")
        ok("http://example.com/stream/playlist.m3u8?token=abc")
        ok("https://cdn.example.com/manifest.mpd")
        ok("  https://example.com/a.mkv  ")
    }

    @Test fun rejectsEmptyAndMalformed() {
        bad("")
        bad("   ")
        bad("example.com/video.mp4")
        bad("https://exa mple.com/v.mp4")
        bad("https://")
    }

    @Test fun rejectsOtherSchemes() {
        bad("ftp://example.com/v.mp4")
        bad("file:///sdcard/v.mp4")
        bad("javascript:alert(1)")
    }

    @Test fun rejectsWebPagesAndStreamingSites() {
        bad("https://example.com/watch.html")
        bad("https://www.youtube.com/watch?v=abc")
        bad("https://youtu.be/abc")
        bad("https://m.netflix.com/title/1")
    }

    @Test fun displayNameHidesQueryString() {
        val name = UrlValidator.displayName("https://cdn.example.com/path/movie.mp4?token=SECRET")
        assertEquals("cdn.example.com / movie.mp4", name)
        assertTrue(!name.contains("SECRET"))
    }
}
