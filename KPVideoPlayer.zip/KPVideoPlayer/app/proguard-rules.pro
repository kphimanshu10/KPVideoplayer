# Media3 ships its own consumer rules. Add project-specific keep rules here if needed.
