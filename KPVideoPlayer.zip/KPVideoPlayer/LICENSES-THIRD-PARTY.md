# Third-party software

| Component | Version | License |
|---|---|---|
| AndroidX Media3 (exoplayer, hls, dash, session, ui, common, datasource, extractor, decoder) | 1.5.1 | Apache License 2.0 |
| AndroidX Core KTX, Activity Compose, Lifecycle | see `gradle/libs.versions.toml` | Apache License 2.0 |
| Jetpack Compose (BOM 2024.10.01), Material 3, Material Icons | | Apache License 2.0 |
| Kotlin standard library and coroutines | 2.0.21 | Apache License 2.0 |
| Guava (transitive, via Media3) | | Apache License 2.0 |
| JUnit (tests only) | 4.13.2 | Eclipse Public License 1.0 |

Apache License 2.0: <https://www.apache.org/licenses/LICENSE-2.0>

## Codecs
The app uses the device's own hardware/software decoders through Android's MediaCodec, plus Media3's built-in container
parsers. No FFmpeg or other third-party codec library is bundled. If you add one later (for example the Media3 FFmpeg
extension), check its LGPL/GPL obligations and patent/codec licensing before distributing.

## Original work
App name, logo (rounded play mark), UI and all source code in this repository are original. No assets or code from
VLC, PLAYit or any other player were copied.
