# Privacy Policy (template — review before publishing)

**App:** KP Video Player (`com.kp.videoplayer`)
**Contact:** _add your contact e-mail here_
**Last updated:** _add date_

KP Video Player does not collect, sell or share personal data.

## What the app stores (on your device only)
- Watch history, resume positions, favorites and recently played URLs, in app-private storage.
- Your settings (theme, accent colour, playback and buffering options).

None of this is uploaded. You can clear history and URLs under **Settings → Privacy**, or by clearing the app's data in Android settings.

## Permissions
- **Videos / storage (READ_MEDIA_VIDEO):** to list videos through Android's media library. Optional; you can open single files without it.
- **Notifications:** to show playback controls while media plays in the background.
- **Internet:** only to play URLs you enter. Requests go directly from your device to that server.
- **Foreground service (media playback) and wake lock:** to keep playback running with the screen off.

## Third parties
The app has no ads, analytics or trackers. A server you stream from can see your IP address and the request, as with any media player.

## Children
The app is not directed at children and collects no data from anyone.
