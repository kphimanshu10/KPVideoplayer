# KP Video Player

Original Android video player (`com.kp.videoplayer`) built with Kotlin, Jetpack Compose (Material 3), MVVM and
AndroidX Media3 / ExoPlayer. Dark-first UI with optional light theme and four accent colours.

> **Build status: source written, NOT yet compiled or run.**
> The environment this was written in had no Android SDK and no access to Google Maven / Maven Central, so Gradle
> could not run. Expect to fix a few compile errors on the first build. Nothing below has been tested on a device.
> The two JVM unit-test files are written but have not been executed either.

## Build an APK

### Option A: no Android Studio (GitHub Actions)
1. Create a GitHub repository and push this folder to it.
2. Open the **Actions** tab → **Build debug APK** → run it (it also runs on every push).
3. Download the `kp-video-player-debug-apk` artifact. It contains `app-debug.apk`. Install it on your phone
   (allow "install unknown apps" for your browser/file manager).
4. If the build fails, open the log; the first Kotlin error is usually the only one that matters.

### Option B: Android Studio
1. Install Android Studio (Ladybug or newer, JDK 17 is bundled). Open this folder.
2. Let Gradle sync (it downloads Android SDK platform 35 on request).
3. Run ▶ on a phone/emulator (Android 11+), or **Build → Build APK(s)**.
   Output: `app/build/outputs/apk/debug/app-debug.apk`.

### Option C: command line
```
export ANDROID_HOME=/path/to/android-sdk     # with platforms;android-35 and build-tools installed
./gradlew testDebugUnitTest assembleDebug
```

### Release signing
```
keytool -genkeypair -v -keystore kp-release.jks -alias kp -keyalg RSA -keysize 2048 -validity 10000
export KP_KEYSTORE=$PWD/kp-release.jks KP_STORE_PASSWORD=... KP_KEY_ALIAS=kp KP_KEY_PASSWORD=...
./gradlew assembleRelease     # app/build/outputs/apk/release/app-release.apk
```
Never commit the keystore (it is git-ignored). Without the variables the release APK is unsigned.

## What is implemented (written, untested)
- Playback via Media3 ExoPlayer in a `MediaSessionService` (background audio, media notification, lock-screen /
  headset / Bluetooth controls, audio focus, "becoming noisy" pause).
- Containers/codecs: whatever Media3 and the device decoders support (MP4, MKV, WebM, MOV, TS, 3GP, FLV, AVI*, MPEG*,
  H.264/HEVC/VP8/VP9/AV1, AAC/MP3/Opus/FLAC/Vorbis). *Support varies by device; unsupported files show a clear error.
- Embedded subtitles plus external SRT / VTT / ASS-SSA / TTML via file picker; audio and subtitle track selection.
- Library: MediaStore discovery, list/grid, search, sort (name/date/duration/size), folders, favorites, history,
  resume position, multi-select, queue playback, delete (system confirmation dialog, Android 11+).
- Player: double-tap seek, brightness/volume swipes, auto-hide controls, speeds 0.25x–3x, lock, rotation modes,
  aspect modes (fit / fill / crop / fixed width / fixed height), Picture-in-Picture, audio-only toggle, sleep timer,
  media info dialog, error screen with Retry, buffering indicator.
- Play URL: http(s) validation, direct files, HLS, DASH, recent-URL history (host + file name shown; query strings
  hidden), web-page detection, readable network errors. URLs are never logged.
- Settings: theme, accent, background audio, auto-PiP, seek step, buffer size, clear history/URLs, privacy policy.
- Open a single file with the system picker (Storage Access Framework) and "Open with" from other apps.

## Not implemented
- Audio equalizer, audio delay, subtitle delay.
- "Original pixel size" aspect mode (fit/fill/crop/width/height only).
- Custom HTTP headers for authorised streams.
- FFmpeg backend (so no extra codecs beyond what Media3 and the device provide).
- SMB / FTP / WebDAV browsing, Chromecast, Android Auto.
- Pinch-to-zoom; horizontal swipe-to-seek (use the seek bar or double-tap).
- Instrumented UI tests, and tests for corrupted media, revoked permissions, slow networks, PiP, low memory and
  accessibility. Only JVM unit tests for URL validation and formatting exist.

## Known limitations
- Cleartext `http://` is allowed (the spec requires HTTP URLs); prefer https.
- Buffer-size changes apply when the playback service next starts.
- Thumbnails use `ContentResolver.loadThumbnail`; very large libraries load them lazily.
- minSdk is 30 (Android 11), because safe deletion uses `MediaStore.createDeleteRequest`.
- DRM, sign-in and paywalled content are intentionally not supported or bypassed.

## Layout
```
app/src/main/java/com/kp/videoplayer/
  KpApp.kt                    application, owns PrefsStore + VideoRepository
  data/                       models, MediaStore repository, SharedPreferences store, queue hand-off
  playback/                   PlaybackService (ExoPlayer + MediaSession), media-item builder, error messages
  player/PlayerActivity.kt    full-screen player (views, gestures, dialogs, PiP)
  ui/                         theme, ViewModel, components, MainActivity, screens/
  util/                       UrlValidator, Fmt
```

See `PRIVACY.md` (template) and `LICENSES-THIRD-PARTY.md`.
